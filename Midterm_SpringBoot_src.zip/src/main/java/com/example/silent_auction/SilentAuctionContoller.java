//SilentAuctionContoller.java

package com.example.silent_auction;

// import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SilentAuctionContoller {

	@GetMapping("/")
	public String showHomePage() {
		return "<html>"
                + "<head><title>Silent Auction</title></head>"
                + "<body>"
                + "<h1>Welcome to the Silent Auction!</h1>"
                + "<button onclick=\"window.location.href='index.html'\">Go to Silent Auction Website</button>"
                + "<p>To see a list of items go to <a href='/items'>localhost:8080/items</a></p>"
                + "</body>"
                + "</html>";
	}


}

