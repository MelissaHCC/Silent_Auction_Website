package com.example.silent_auction;

import java.util.ArrayList;

public class Items {
	private ArrayList<Item> items;

	public Items() {
		items = new ArrayList<Item>();
		items.add(new Item(1, "Mixed Alcohol Basket", "Indulge in this exclusive assortment of fine wines and premium spirits, handpicked to elevate your gatherings and celebrations. Whether you're a connoisseur or looking for a gift, this collection offers a taste of luxury."));
		items.add(new Item(2, "Pearl Necklace", "Elegant and timeless, this classic pearl necklace adds a touch of sophistication to any outfit. Carefully crafted with lustrous pearls, it’s the perfect addition to any jewelry collection, symbolizing grace and beauty."));
		items.add(new Item(3, "Baking Kit Basket", "Everything you need to create delicious treats at home! This deluxe baking set includes high-quality pans, measuring tools, and decorating accessories, ideal for bakers of all skill levels who love crafting sweet creations."));
				
	}

	public ArrayList<Item> getItems() {
		return items;
	}

	public void setItems(ArrayList<Item> items) {
		this.items = items;
	}
	

}
