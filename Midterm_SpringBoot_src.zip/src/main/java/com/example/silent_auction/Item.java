package com.example.silent_auction;

public class Item {
	private int itemId;
	private String itemName;
	private String itemDescription;

	public Item() {
		// TODO Auto-generated constructor stub
	}

	public Item(int i, String n, String d) {
		itemId = i;
		itemName = n;
		itemDescription = d;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	
	@Override
	public String toString() {
		return "Item{" + "id=" + this.itemId + ", name='" +
				this.itemName + "', description='" + this.itemDescription + "'}";

	}
	

}
